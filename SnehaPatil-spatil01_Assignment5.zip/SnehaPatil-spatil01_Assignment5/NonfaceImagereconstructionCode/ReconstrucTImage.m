function w = ReconstrucTImage(testImage,R,C,U,M,avg)
 testIm=imread(testImage);
 Gra = rgb2gray(testIm);
 B = imresize(Gra,[R C]);
    T=reshape(B,R*C,1);
    T=double(T);
    
    O=T-avg;
 n=  norm(U);
 U = U./n;
    % projection of the test face on the eigenfaces
    w=U'*O;
    size(w);
    rec = zeros(R*C,1);
for j = 1: size(w, 1)
    for i = 1:size(U,1)
    rec(i,1) = U(i,j)* w(j,1)+ rec(i,1);
    end
end

reconst = imadd(U*w , avg);
reconstructedImg = reshape(rec + avg,[R,C]);
figure;
 subplot(1,3,1);
 imshow(testIm);
 title('Test face');
 subplot(1,3,2);
imshow(reconstructedImg,[]);
 title('Reconstructed face');
 subplot(1,3,3);
 diffimg = imabsdiff(double(B), double(reconstructedImg));
imshow(diffimg,[]);
 title('Difference image');