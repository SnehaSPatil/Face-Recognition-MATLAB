function testingEigenFaces(Efimage, Eknown,StoredImages,R,C,M,avg,U,omega,testdirpath)
    drs=testdirpath; 
FileList=dir([drs '/subject*.*']); 
NumTest=length(FileList); 
for j=1:NumTest
     current = FileList(j).name;
     current = strcat(drs , '/', current);
    testIm=imread(current);
        
    T=reshape(testIm,R*C,1);
    T=double(T);
    
    O=T-avg;
    
    % projection of the test face on the eigenfaces
    w=U'*O;
% reconstructedImg = reshape(U*w,[R,C]);
% figure;
% imshow(reconstructedImg,[]);
    d=repmat(w,1,M)-omega;
    
    dist=zeros(M,1);
     
    % find the distance from all training faces
    for i=1:M
        dist(i,1)=norm(d(:,i));
    end

    min_element=min(dist);
    for i=1:size(dist,1)
    if dist(i,1) == min_element
        minIndex=i;
        break;
    end
    end
    figure;
    if minIndex < Efimage
        subplot(1,2,1);
        imshow(testIm);
        title('Test face Not a face');
    elseif minIndex < Eknown 
        subplot(1,2,1);
        imshow(testIm);
        title('Test face Not recognized');
     else
        subplot(1,2,1);
        imshow(testIm);
        title('Test face');
        subplot(1,2,2);
        imshow(uint8(StoredImages(:,:,minIndex)));
        title('Recognized face');
    end
end
end