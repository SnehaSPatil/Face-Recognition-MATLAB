function [StoredImages,R,C,M,avg,U,omega,V,timeElp]=trainingEigenFaces(method,num,dirpath)
drs=dirpath; 
FileList=dir([drs '/subject*.*']); 
current = FileList(1).name;
current = strcat(drs , '/', current);
im=imread(current);
R=size(im,1); 
C=size(im,2); 
M=length(FileList); 

StoredImages=zeros(R,C,M);
vec=zeros(R*C,M);
    for i=1:M
        current = FileList(i).name;
        current = strcat(drs , '/', current);
        StoredImages(:,:,i)=imread(current);
        vec(:,i)=reshape(StoredImages(:,:,i),R*C,1);
    end
        
    % mean face
avg=sum(vec,2)/M;
imshow(reshape(avg,[R,C]), []);
title('Average face');


    % face space
    A=vec-repmat(avg,1,M);
    tic
if(method == 1)
    L=A*A';
    [V,D]=eig(L);
elseif (method == 2)
    L=A'*A;
    [V,D]=eig(L);
else
    n = sqrt(R-1);
    K = A'/n;
    [u,S,V] = svd(K);
end
timeElp = toc;
disp(toc);
% sort the eigenvalues in descending order

 eigValue = diag(D);
 [temp sortind] = sort(eigValue,'descend');
 eigValue = eigValue(sortind);
 V = V(:,sortind); 
 for  i = 1:num
     eigVector(:,i) = V(:,i);
 end
 % display the eigenvalues
n_evalues = eigValue / sum(eigValue);
figure, plot(cumsum(n_evalues));
xlabel('No. of eigenvectors'), ylabel('Variance accounted for');
xlim([1 120]), ylim([0 1]), grid on;
% These are the eigenfaces
     U=A*eigVector;
     
   omega=U'*A;

end
